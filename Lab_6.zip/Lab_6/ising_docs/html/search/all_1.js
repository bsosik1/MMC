var searchData=
[
  ['energia_5fdocelowa_5fukładu_2',['energia_docelowa_układu',['../classModelIsinga.html#a6bd22cc1552bb654f4f60a78161bac4c',1,'ModelIsinga']]],
  ['energia_5fduszka_3',['energia_duszka',['../classModelIsinga.html#a8c8824cc8977a98e530cb911b7a419f8',1,'ModelIsinga']]]
];
