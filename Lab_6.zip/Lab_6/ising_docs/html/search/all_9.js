var searchData=
[
  ['zliczanie_5fśrednich_17',['zliczanie_średnich',['../classModelIsinga.html#ac1520d58c477b4bc9f07a2650debcd31',1,'ModelIsinga']]]
];
