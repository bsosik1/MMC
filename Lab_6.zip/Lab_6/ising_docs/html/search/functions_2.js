var searchData=
[
  ['modelisinga_28',['ModelIsinga',['../classModelIsinga.html#a582bd14b099bab959913a9e79cfa757e',1,'ModelIsinga']]]
];
