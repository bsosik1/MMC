var searchData=
[
  ['modelisinga_19',['ModelIsinga',['../classModelIsinga.html',1,'']]]
];
