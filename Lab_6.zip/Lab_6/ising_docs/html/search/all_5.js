var searchData=
[
  ['model_5fisinga_2eh_9',['model_isinga.h',['../model__isinga_8h.html',1,'']]],
  ['modelisinga_10',['ModelIsinga',['../classModelIsinga.html',1,'ModelIsinga'],['../classModelIsinga.html#a582bd14b099bab959913a9e79cfa757e',1,'ModelIsinga::ModelIsinga()']]]
];
