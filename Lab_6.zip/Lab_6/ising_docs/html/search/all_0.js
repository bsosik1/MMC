var searchData=
[
  ['deltae_0',['deltaE',['../classModelIsinga.html#afb46179ec97972a34e27ca41e554ebee',1,'ModelIsinga']]],
  ['doprowadzenie_5fdo_5fstanu_5frównowagi_1',['doprowadzenie_do_stanu_równowagi',['../classModelIsinga.html#a514cab2ef437193c5c8f9453b82d93bc',1,'ModelIsinga']]]
];
