var searchData=
[
  ['model_5fisinga_2eh_22',['model_isinga.h',['../model__isinga_8h.html',1,'']]]
];
