var searchData=
[
  ['ising_5fmain_2ecpp_21',['ising_main.cpp',['../ising__main_8cpp.html',1,'']]]
];
