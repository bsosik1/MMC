var searchData=
[
  ['losuj_5fwspółrzedną_26',['losuj_współrzedną',['../classRNG.html#a9587eb41aaf02e5fbf22b7d558f45db0',1,'RNG']]],
  ['losuj_5fz_5fzakresu_5f0_5f1_27',['losuj_z_zakresu_0_1',['../classRNG.html#a24aec02694597f86840ce4291216a8a9',1,'RNG']]]
];
