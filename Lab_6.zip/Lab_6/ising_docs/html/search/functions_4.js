var searchData=
[
  ['spróbuj_5fodwrócić_5fspin_5flosowego_5fatomu_30',['spróbuj_odwrócić_spin_losowego_atomu',['../classModelIsinga.html#a56fb0f29b4d9661161104216d4c848aa',1,'ModelIsinga']]]
];
