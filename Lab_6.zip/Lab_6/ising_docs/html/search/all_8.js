var searchData=
[
  ['ustaw_5fsame_5fjedynki_16',['ustaw_same_jedynki',['../classModelIsinga.html#a3ac78369f685557988c738332a13195f',1,'ModelIsinga']]]
];
