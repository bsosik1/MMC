var indexSectionsWithContent =
{
  0: "degilmrsuzź",
  1: "mr",
  2: "imr",
  3: "dlmrsuz",
  4: "eglrź"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Pliki",
  3: "Funkcje",
  4: "Zmienne"
};

